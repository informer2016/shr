#!/bin/sh

# Checks if line '$1' contains the text '$2'.
checker () {
    case "$1" in
        *"$2"*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# Checks if a file '$1' exists.
file_exists () {
    if [ ! -f "$1" ] ; then
        printf "\nWARNING: file $1 is not found !\n\n"
        return 1
    else
        return 0
    fi
}

# Adds a '$1' visopsys floppy image to coreboot '$3' ROM using '$2' cbfstool.
floppy_adder () {
    if file_exists "$1" && file_exists "$2" && file_exists "$3" ; then
        floppy_adder_cbfs=$( "$2" "$3" print )
        if checker "$floppy_adder_cbfs" "floppyimg/visopsys.lzma" ; then
            "$2" "$3" remove -n "floppyimg/visopsys.lzma"
        fi
        "$2" "$3" add -f "$1" -n "floppyimg/visopsys.lzma" -t raw -c lzma
        "$2" "$3" print
        printf "\nVisopsys successfully updated !\n\n"
        return 0
    else
        return 1
    fi
}

if [ ! -z "$1" ] ; then
    floppy_adder "$1" "./cbfstool" "./coreboot.rom"
    exit 0
else
    printf "\nUSAGE: $0 ./path_to_visopsys.img\n\n"
    exit 1
fi
