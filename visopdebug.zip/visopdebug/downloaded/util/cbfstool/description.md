__cbfstool__
  * _cbfstool_ - For manipulating CBFS file `C`
  * _fmaptool_ - Converts plaintext fmd files into fmap blobs `C`
  * _rmodtool_ - Creates rmodules `C`
  * _ifwitool_ - For manipulating IFWI `C`
