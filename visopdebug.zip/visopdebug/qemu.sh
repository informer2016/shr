#!/bin/sh
qemu-system-x86_64 -L . -m 256 -localtime -vga vmware -net nic,model=rtl8139 \
 -net user -soundhw ac97 -usb -usbdevice tablet -bios ./coreboot.rom -serial stdio
